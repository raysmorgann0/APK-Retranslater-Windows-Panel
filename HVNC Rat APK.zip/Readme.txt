Open the .exe file panel
Everything you need is installed from the server
Login: Userdata
Password:Network000
make an APK build
distributed
All the best!